function result = Cb(nx , ny , ix , iy , dt , dl)

epsilion = 1/(36 * pi * 10 ^ 9);

permittivity = epsilion * ones(2 * nx + 1 , ny);

omega = 5.8 * 10^7 * ones(2 * nx + 1 , ny);

result = ( (dt)/(permittivity(ix , iy) * dl) )/(1 + (omega(ix , iy) * dt)/(2 * permittivity(ix , iy) ) );