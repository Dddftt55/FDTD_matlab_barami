function result = Ca(nx , ny , ix , iy , dt)

epsilion = 1/(36 * pi * 10 ^ 9);

permittivity = epsilion * ones(2 * nx + 1 , ny);

omega = 5.8 * 10^7 * ones(2 * nx + 1 , ny); %도전율은 구리의 그것으로 가정

result = (1 -  (omega(ix , iy) * dt)/(2 * permittivity(ix , iy)) )/(1 + (omega(ix , iy) * dt)/(2 * permittivity(ix , iy) ) );
