function result = Da(nx , ny , ix , iy , dt)

muon = 4 * pi / 10 ^ 7;

permeability = muon * ones(2 * nx + 1 , ny);

omega_s = 5.8 * 10^7 * ones(2 * nx + 1 , ny);

result = (1 - (omega_s(ix , iy) * dt)/(2 * permeability(ix , iy) ) )/(1 + (omega_s(ix , iy) * dt)/(2 * permeability(ix , iy) ) );