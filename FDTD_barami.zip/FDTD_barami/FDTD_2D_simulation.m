clear all;
clc;

Nx = 6;
Ny = 6;

Nt = 100;

dt = 0.001;

dl = 0.001; %delta_x = delta_y = delta_z = 0.001

epsilion = 1/(36 * pi * 10 ^ 9);
muon = 4 * pi / 10 ^ 7;

c = 1/sqrt(epsilion * muon);

permittivity = epsilion * ones(2 * Nx + 1 , Ny);
permeability = muon * ones(2 * Nx + 1 , Ny);

omega =  5.8 * 10^7 * ones(2 * Nx + 1 , Ny);
omega_s = 5.8 * 10^7 * ones(2 * Nx + 1 , Ny);

Ex = zeros(2 * Nx + 1 , Ny + 1); %전/자계가 저장될 행렬
Ey = zeros(2 * Nx + 1 , Ny + 1);
Ez = zeros(2 * Nx + 1 , Ny + 1);

Hx = zeros(2 * Nx + 1 , Ny + 1);
Hy = zeros(2 * Nx + 1 , Ny + 1);
Hz = zeros(2 * Nx + 1 , Ny + 1);

t = dt : dt : Nt * dt; %source를 위한 시간 설정

f_0 = 10^7;
E_0 = 100;

guassian_modulated_pulse = ones(1 ,Nt); %이 3차원 공간의 source

for ti = 1 : Nt
    if ti == 1 %source part substitute
        Ez(1 , 2) = guassian_modulated_pulse(ti); 
    else
        Ez(1 , 2) = Ez(1 , 2) + guassian_modulated_pulse(ti) - guassian_modulated_pulse(ti - 1) ;
    end

    %%TMz part
    for eziy = 1 : Ny
        if rem(eziy , 2) == 1 %%홀수번째
            if eziy == 1
                for ezix = 1 : Nx
                    Ez(2 * ezix , eziy) = Ca(Nx , Ny , 2 * ezix , eziy , dt) * Ez(2 * ezix , eziy) + Cb(Nx , Ny , 2 * ezix , eziy , dt , dl) * (Hy(2 * ezix + 1 , eziy) - Hy(2 * ezix - 1 , eziy) - Hx(2 * ezix , eziy + 1) );
                end
            else
                for ezix = 1 : Nx
                    Ez(2 * ezix , eziy) = Ca(Nx , Ny , 2 * ezix , eziy , dt) * Ez(2 * ezix , eziy) + Cb(Nx , Ny , 2 * ezix , eziy , dt , dl) * (Hy(2 * ezix + 1 , eziy) - Hy(2 * ezix - 1 , eziy) + Hx(2 * ezix , eziy - 1) - Hx(2 * ezix , eziy + 1) );
                end
            end
        else %%짝수번째
            for ezix = 1 : Nx
                if ezix == 1
                    Ez(2 * ezix - 1 , eziy) = Ca(Nx , Ny , 2 * ezix - 1 , eziy , dt) * Ez(2 * ezix - 1 , eziy) + Cb(Nx , Ny , 2 * ezix - 1 , eziy , dt , dl) * (Hy(2 * ezix , eziy) + Hx(2 * ezix - 1 , eziy - 1) - Hx(2 * ezix , eziy + 1) );
                else
                    Ez(2 * ezix - 1 , eziy) = Ca(Nx , Ny , 2 * ezix - 1 , eziy , dt) * Ez(2 * ezix - 1 , eziy) + Cb(Nx , Ny , 2 * ezix - 1 , eziy , dt , dl) * (Hy(2 * ezix , eziy) - Hy(2 * ezix - 2 , eziy) + Hx(2 * ezix - 1 , eziy - 1) - Hx(2 * ezix , eziy + 1) );
                end
            end
        end
    end
    
    for hxiy = 1 : Ny
        if rem(hxiy , 2) == 1
            if hxiy == 1
                for hxix = 1 : Nx
                    Hx(2 * hxix - 1 , hxiy) = Da(Nx, Ny , 2 * hxix - 1 , hxiy , dt) * Hx(2 * hxix - 1 , hxiy) + Db(Nx , Ny , 2 * hxix - 1 , hxiy , dt , dl) * ( Ez(2 * hxix , hxiy + 1) );
                end
            else
                for hxix = 1 : Nx
                    Hx(2 * hxix - 1 , hxiy) = Da(Nx, Ny , 2 * hxix - 1 , hxiy , dt) * Hx(2 * hxix - 1 , hxiy) + Db(Nx , Ny , 2 * hxix - 1 , hxiy , dt , dl) * (Ez(2 * hxix , hxiy - 1) - Ez(2 * hxix , hxiy + 1) );
                end
            end
        else
            for hxix = 1 : Nx
                Hx(2 * hxix , hxiy) = Da(Nx , Ny , 2 * hxix , hxiy , dt) * Hx(2 * hxix , hxiy) + Db(Nx , Ny , 2 * hxix , hxiy , dt , dl) * (Ez(2 * hxix , hxiy - 1) - Ez(2 * hxix , hxiy + 1) );
            end
        end
    end

    for hyiy = 1 : Ny
        if rem(hyiy , 2) == 1
            if hyiy == 1
                for hyix = 1 : Nx
                    Hy(2 * hyix - 1 , hyiy) = Da(Nx , Ny , 2 * hyix - 1 , hyiy , dt) * Hy(2 * hyix - 1 , hyiy) + Db(Nx , Ny , 2 * hyix - 1 , hyiy , dt , dl) * (- Ez(2 * hyix - 1 , hyiy + 1) );
                end
            else
                for hyix = 1 : Nx
                    Hy(2 * hyix - 1 , hyiy) = Da(Nx , Ny , 2 * hyix - 1 , hyiy , dt) * Hy(2 * hyix - 1 , hyiy) + Db(Nx , Ny , 2 * hyix - 1 , hyiy , dt , dl) * (Ez(2 * hyix - 1 , hyiy - 1) - Ez(2 * hyix - 1 , hyiy + 1) );
                end
            end
        else
            for hyix = 1 : Nx
                Hy(2 * hyix, hyiy) = Da(Nx , Ny , 2 * hyix , hyiy , dt) * Hy(2 * hyix , hyiy) + Db(Nx , Ny , 2 * hyix , hyiy , dt , dl) * (Ez(2 * hyix , hyiy - 1) - Ez(2 * hyix , hyiy + 1) );
            end
        end
    end


    %%TEz part

    if ti == 1 %source part substitute
        Hz(1 , 2) = guassian_modulated_pulse(ti); 
    else
        Hz(1 , 2) = Hz(1 , 2) + guassian_modulated_pulse(ti) - guassian_modulated_pulse(ti - 1) ;
    end


    for exiy = 1 : Ny               
        if rem(exiy , 2) == 1
            if exiy == 1
                for exix = 1 : Nx
                    Ex(2 * exix - 1 , exiy) = Ca(Nx , Ny , 2 * exix - 1 , exiy , dt) * Ex(2 * exix - 1 , exiy) + Cb(Nx , Ny , 2 * exix - 1 , exiy , dt , dl) * (Hz(2 * exix - 1 , exiy) );
                end
            else
                for exix = 1 : Nx
                    Ex(2 * exix - 1 , exiy) = Ca(Nx , Ny , 2 * exix - 1 , exiy , dt) * Ex(2 * exix - 1 , exiy) + Cb(Nx , Ny , 2 * exix - 1 , exiy , dt , dl) * (Hz(2 * exix - 1 , exiy) - Hz(2 * exix - 1 , exiy - 1) );
                end
            end
        else
            for exix = 1 : Nx
                Ex(2 * exix , exiy) = Ca(Nx , Ny , 2 * exix , exiy , dt) * Ex(2 * exix , exiy) + Cb(Nx , Ny , 2 * exix , exiy , dt , dl) * (Hz(2 * exix , exiy + 1) - Hz(2 * exix , exiy - 1) );
            end
        end
    end

    for eyiy = 1 : Ny
        if rem(eyiy , 2) == 1
            for eyix = 1 : Nx
                if eyix == 1
                    Ey(2 * eyix , eyiy) = Ca(Nx , Ny , 2 * eyix , eyiy , dt) * Ey(2 * eyix , eyiy) + Cb(Nx , Ny , 2 * eyix , eyiy , dt , dl) * ( - Hz(2 * eyix , eyiy) );
                else
                    Ey(2 * eyix , eyiy) = Ca(Nx , Ny , 2 * eyix , eyiy , dt) * Ey(2 * eyix , eyiy) + Cb(Nx , Ny , 2 * eyix , eyiy , dt , dl) * (Hz(2 * eyix - 2 , eyiy) - Hz(2 * eyix , eyiy) );
                end
            end
        else
            for eyix = 1 : Nx
                Ey(2 * eyix , eyiy) = Ca(Nx , Ny , 2 * eyix , eyiy , dt) * Ey(2 * eyix , eyiy) + Cb(Nx , Ny , 2 * eyix , eyiy , dt , dl) * (Hz(2 * eyix - 1 , eyiy) - Hz(2 * eyix , eyiy) );
            end
        end
    end
    
    for hziy = 1 : Ny
        if rem(hziy , 2) == 1
            if hziy == 1
                for hzix = 1 : Nx
                    Hz(2 * hzix , hziy) = Ca(Nx , Ny , 2 * hzix , hziy , dt) * Hz(2 * hzix , hziy) + Cb(Nx , Ny , 2 * hzix , hziy , dt , dl) * (Ex(2 * hzix , hziy + 1) + Ey(2 * hzix - 1 , hziy) - Ey(2 * hzix + 1 , hziy) );
                end
            else
                for hzix = 1 : Nx
                    Hz(2 * hzix , hziy) = Ca(Nx , Ny , 2 * hzix , hziy , dt) * Hz(2 * hzix , hziy) + Cb(Nx , Ny , 2 * hzix , hziy , dt , dl) * (Ex(2 * hzix , hziy + 1) - Ex(2 * hzix , hziy - 1) + Ey(2 * hzix - 1 , hziy) - Ey(2 * hzix + 1 , hziy) );
                end
            end
        else
            for hzix = 1 : Nx
                if hzix == 1
                    Hz(2 * hzix - 1 , hziy) = Ca(Nx , Ny , 2 * hzix - 1 , hziy , dt) * Cb(Nx , Ny , 2 * hzix - 1 , hziy , dt , dl) * (Ex(2 * hzix - 1 , hziy + 1) - Ex(2 * hzix - 1 , hziy - 1) - Ey(2 * hzix , hziy) );
                else
                    Hz(2 * hzix - 1 , hziy) = Ca(Nx , Ny , 2 * hzix - 1 , hziy , dt) * Cb(Nx , Ny , 2 * hzix - 1 , hziy , dt , dl) * (Ex(2 * hzix - 1 , hziy + 1) - Ex(2 * hzix - 1 , hziy - 1) + Ey(2 * hzix - 2 , hziy) - Ey(2 * hzix , hziy) );
                end
            end
        end 
    end
end