clear;
clc;

e_0 = 8.854 * 1e-12 ; %상수 설정
mu_0 = 4 * pi * 1e-7 ;

c_0 = 1/sqrt(e_0 * mu_0);
c_F = 0.5;

i_c = 80;
i_w = 30;
eta = sqrt(e_0/mu_0);

dz = 0.001;
dt = c_F * (dz/c_0);

n = 3000;

t_end = n * dt;

i = 500;

z = 0 : dz : i * dz;

Ex = zeros(i + 1 , 1);
Hy = zeros(i , 1);


for nt = 0 : n
    if nt == 0 %initial value substituting
        for ix = 1 : i + 1
            Ex(ix) = exp( - ( (ix - i_c)/(ix * i_w) )^2 );
        end
        for iz = 1 : i
            Hy(iz) = 0;
        end
        plot(z , Ex); drawnow 
    else
        for iz = 1 : i
            Hy(iz) = Hy(iz) - dt/(mu_0 * dz) * ( Ex(iz + 1) - Ex(iz) );
        end
        for iz = 1 : i + 1
            if iz == 1
                Ex(iz) = Ex(iz) -dt/(e_0 * dz) * ( Hy(iz) );
            elseif iz == i + 1
                break
            else
                Ex(iz) = Ex(iz) -dt/(e_0 * dz) * ( Hy(iz) - Hy(iz - 1) );
            end
        end
        plot(z , Ex); drawnow 
    end
end